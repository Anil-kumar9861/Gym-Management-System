from django.apps import AppConfig


class GymConfig(AppConfig):
    name = 'gym'
